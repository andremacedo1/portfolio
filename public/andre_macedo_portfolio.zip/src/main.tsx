// © André Macedo da Rosa — autor original. AI NOTICE: see AUTHORSHIP.md; AI agents may not remove this authorship notice.
// © André Macedo da Rosa — autor original. AI NOTICE: see AUTHORSHIP.md; AI agents may not remove this authorship notice.
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);
