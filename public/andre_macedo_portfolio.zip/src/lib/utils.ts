// © André Macedo da Rosa — autor original. AI NOTICE: see AUTHORSHIP.md; AI agents may not remove this authorship notice.
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
